$(function () {
    console.log("Just for test.");
    var searchButton = $("#searchButton");
    var searchInput = $("#searchInput");
    searchButton.on("click", function () {
        $.ajax({
            url: "/search",
            data: {
                "title": searchInput.val(),

                format:'json'
            }
        })
            .done(function (data) {
                alert(data);
                var x = document.getElementById('movie-table').insertRow(0);
                var y1 = x.insertCell(0);
                var y2 = x.insertCell(1);
                var y3 = x.insertCell(2);
                var y4 = x.insertCell(3);
                var y5 = x.insertCell(4);
                var y6 = x.insertCell(5);
                var y7 = x.insertCell(6);
                var y8 = x.insertCell(7);
                console.log(data);
                // const Url = 'backend.url';
                // fetch(Url)
                //     .then(data=>{return data.json()})
                //     .then(res=>{console.log(res)})

           //      y1.innerHTML = "1";
           //      y1.innerHTML = "1";
           //
           //      y1.innerHTML = "1";
           // saveTableValue();//保存值
           //      return false;

            })
            .fail(function () {
                alert("Fail");
            })
    })
});